<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Conversation;
use App\Models\Message;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class MessageController extends Controller
{
    public function index()
    {
        $conversations = Conversation::with([
            'messages' => function ($query) {
                $query->latest()->limit(1); // only latest message
            },
            'userOne',
            'userTwo'
        ])
            ->orderByDesc(
                Message::select('created_at')
                    ->whereColumn('conversation_id', 'conversations.id')
                    ->latest()
                    ->limit(1)
            )
            ->get();
        return view('admin.message.index', [
            'conversations' =>  $conversations
        ]);
    }

    public function detail($id)
    {

        $conversation = Conversation::findorfail($id);
        $messages = Message::where('conversation_id', $id)
            ->get();
        $user = User::where('users.is_admin', 0)->where('id', $conversation->user_one_id)->first();
        return view('admin.message.detail', [
            'messages' =>  $messages,
            'user' =>  $user
        ]);
    }
}
