/******/ (() => { // webpackBootstrap
/*!************************************************!*\
  !*** ./resources/js/pages/jquery-knob.init.js ***!
  \************************************************/
/*
Template Name: Dason - Admin & Dashboard Template
Author: Themesdesign
Website: https://themesdesign.in/
Contact: themesdesign.in@gmail.com
File: Jquery knob init Js File
*/

$(function () {
  $(".knob").knob();
});
/******/ })()
;