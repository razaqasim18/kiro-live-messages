/******/ (() => { // webpackBootstrap
/*!************************************************!*\
  !*** ./resources/js/pages/task-create.init.js ***!
  \************************************************/
tinymce.init({
  selector: 'textarea#default-editor'
});
/******/ })()
;