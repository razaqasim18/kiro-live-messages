@extends('layouts.master')
@section('title')
    @lang('translation.Read_Email')
@endsection
@section('css')
@endsection
@section('content')
    @component('components.breadcrumb')
        @slot('li_1')
            Messages
        @endslot
        @slot('title')
            Messages
        @endslot
    @endcomponent

    <div class="d-lg-flex">

        <div class="w-100 user-chat mt-4 mt-sm-0 ms-lg-1">
            <div class="card">
                <div class="p-3 px-lg-4 border-bottom">
                    <div class="row">
                        <div class="col-xl-4 col-7">
                            <div class="d-flex align-items-center">
                                <div class="flex-shrink-0 avatar-sm me-3 d-sm-block d-none">
                                    <img src="@if ($user->avatar != '') {{ URL::asset('storage/' . $user->avatar) }}@else{{ URL::asset('assets/images/users/avatar-1.jpg') }} @endif"
                                        alt="" class="img-fluid d-block rounded-circle">
                                </div>
                                <div class="flex-grow-1">
                                    <h5 class="font-size-14 mb-1 text-truncate"><a href="#" class="text-dark">
                                            {{ $user->name }}
                                        </a></h5>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-8 col-5">
                        </div>
                    </div>
                </div>

                <div class="chat-conversation p-3" data-simplebar style="max-height: 550px;">
                    <ul class="list-unstyled mb-0">
                        {{-- <li class="chat-day-title">
                            <span class="title">Today</span>
                        </li> --}}
                        @php
                            $currentUserId = $user->id;
                        @endphp
                        @foreach ($messages as $row)
                            @php
                                $isSender = $row->sender_id == $currentUserId;
                                $user = $row->sender;
                                $avatar = $user->avatar
                                    ? asset('storage/' . $user->avatar)
                                    : asset('assets/images/users/avatar-1.jpg');
                            @endphp

                            <li class="{{ $isSender ? 'right' : '' }}">
                                <div class="conversation-list">
                                    <div class="d-flex {{ $isSender ? 'flex-row-reverse' : '' }}">
                                        <img src="{{ $avatar }}" class="rounded-circle avatar-sm" alt="Avatar">

                                        <div class="flex-1">
                                            <div class="ctext-wrap">
                                                <div class="ctext-wrap-content">
                                                    <div class="conversation-name">
                                                        <span class="time">{{ $row->created_at->format('H:i a') }}</span>
                                                    </div>

                                                    @if ($row->message)
                                                        <p class="mb-0">{{ $row->message }}</p>
                                                    @endif
                                                    @if ($row->image_path)
                                                        <img src="{{ asset('storage/' . $row->image_path) }}" alt="Image"
                                                            class="rounded img-thumbnail image-popup">
                                                    @endif
                                                    @php
                                                        $allowedExtensions = ['mp4', 'webm', 'ogg'];
                                                        $extension = pathinfo($row->video_path, PATHINFO_EXTENSION);
                                                    @endphp

                                                    @if ($row->video_path)
                                                        @if (in_array(strtolower($extension), $allowedExtensions))
                                                            <a
                                                                class="image-popup-video-map"href="{{ asset('storage/' . $row->video_path) }}">
                                                                <video width="320" height="240" controls>
                                                                    <source
                                                                        src="{{ asset('storage/' . $row->video_path) }}"
                                                                        type="video/{{ strtolower($extension) }}">
                                                                    Your browser does not support the video tag.
                                                                </video>
                                                            </a>
                                                        @else
                                                            <p>Invalid or unsupported video format.</p>
                                                        @endif
                                                    @endif

                                                    @if ($row->voice_note_path)
                                                        <audio controls>
                                                            <source src="{{ asset('storage/' . $row->voice_note_path) }}"
                                                                type="audio/mpeg">
                                                            Your browser does not support the audio element.
                                                        </audio>
                                                    @endif

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>
                        @endforeach


                    </ul>
                </div>
            </div>
        </div>
        <!-- end user chat -->
    </div>
    <!-- End d-lg-flex  -->
@endsection
@section('script')
    <script src="{{ URL::asset('/assets/js/app.min.js') }}"></script>
@endsection
